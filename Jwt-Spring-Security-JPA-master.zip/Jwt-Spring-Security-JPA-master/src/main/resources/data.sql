--Add initial role
INSERT INTO login_db.role (ROLE_NAME) VALUES ('ROLE_USER');
INSERT INTO login_db.role (ROLE_NAME) VALUES ('ROLE_ADMIN');



